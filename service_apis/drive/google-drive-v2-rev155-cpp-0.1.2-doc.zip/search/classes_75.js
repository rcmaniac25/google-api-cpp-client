var searchData=
[
  ['user',['User',['../classgoogle__drive__api_1_1User.html',1,'google_drive_api']]],
  ['userpicture',['UserPicture',['../classgoogle__drive__api_1_1User_1_1UserPicture.html',1,'google_drive_api::User']]]
];
